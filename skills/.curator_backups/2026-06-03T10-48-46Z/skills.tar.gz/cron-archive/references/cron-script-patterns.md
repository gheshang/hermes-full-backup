# Cron Script Execution Pattern (no_agent + script)

## Overview

Hermes Cron supports a **pure script execution mode** that bypasses the LLM entirely. This is ideal for deterministic tasks like monitoring, data collection, and scheduled scripts.

## Configuration

```python
cronjob(action='create',
    script='/path/to/script.sh',      # or .py, .bash
    no_agent=True,                     # KEY: skip LLM, run script directly
    schedule='0 8 * * *',
    deliver='feishu'                   # stdout delivered to Feishu
)
```

## Behavior

| Condition | Result |
|-----------|--------|
| Script stdout non-empty | Sent verbatim to `deliver` target |
| Script stdout empty | Silent — nothing delivered |
| Script exits non-zero / timeout | Error alert sent |

## Use Cases

- **Monitoring**: Disk space, CPU, memory thresholds
- **Data collection**: Scheduled scraping, API polling
- **Change detection**: File/directory change watchers
- **CI notifications**: Build/test status alerts

## Script Requirements

1. **Must be self-contained** — no reliance on parent session context
2. **Must produce output** — empty stdout = silent (watchdog pattern)
3. **Must handle errors** — non-zero exit triggers alert
4. **Path resolution**: Relative paths resolve under `~/.hermes/scripts/`
5. **Extensions**: `.sh`/`.bash` → bash, everything else → Python

## Example: lian-zhou-jobs Pattern

```python
# System crontab (not Hermes Cron):
0 8 * * * cd /home/hangskf && python3 ~/.hermes/scripts/lianzhou_jobs_crawler.py >> ~/.hermes/cron/lian-zhou-jobs/cron.log 2>&1

# Equivalent Hermes Cron:
cronjob(action='create',
    script='/home/hangskf/.hermes/scripts/lianzhou_jobs_crawler.py',
    no_agent=True,
    schedule='0 8 * * *',
    deliver='feishu'
)
```

## Pitfalls

- **Don't use `no_agent=True` for reasoning tasks** — it skips the LLM entirely
- **Empty stdout = silent** — design scripts to always produce output (even "OK")
- **Errors are silent without non-zero exit** — always `exit 1` on failure
- **Context is NOT injected** — the script runs in a fresh session with no chat context
