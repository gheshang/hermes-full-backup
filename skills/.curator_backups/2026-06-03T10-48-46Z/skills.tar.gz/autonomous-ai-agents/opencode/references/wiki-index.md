# OpenCode Wiki 知识库完整索引

> 来源：`~/wiki/opencode/`，共 77 个文档
> 对应手册：`opencode-manual` SKILL.md v2.0.0
> 最后更新：2026-05-19

---

## Entities（实体文档，21 个）

| # | 文件名 | 主题 | 对应手册章节 |
|---|--------|------|-------------|
| 1 | `opencode.md` | OpenCode 总览 | §1 这是什么 |
| 2 | `opencode-installation.md` | 安装指南 | §2 怎么装 |
| 3 | `opencode-configuration.md` | 配置详解 | §3 怎么配 |
| 4 | `opencode-cli-commands.md` | CLI 命令参考 | §4 命令速查 |
| 5 | `opencode-tui.md` | TUI 交互指南 | §5 TUI 怎么用 |
| 6 | `opencode-models.md` | 模型与提供商 | §6 模型怎么选 |
| 7 | `opencode-agents.md` | 代理系统 | §7 代理是什么 |
| 8 | `opencode-tools.md` | 内置工具 | §8 工具与权限 |
| 9 | `opencode-mcp.md` | MCP 服务器 | §9 MCP 扩展 |
| 10 | `opencode-github.md` | GitHub 集成 | §10 GitHub 自动化 |
| 11 | `opencode-vs-claude-code.md` | 与 Claude Code 对比 | §17 对比 |
| 12 | `opencode-permissions.md` | 权限控制 | §8.2-8.3 权限 |
| 13 | `opencode-lsp.md` | LSP 语言服务器 | §8.4 LSP |
| 14 | `opencode-sdk.md` | SDK 介绍 | §20 SDK 开发 |
| 15 | `opencode-enterprise.md` | 企业部署 | §18 企业怎么用 |
| 16 | `opencode-share.md` | 会话分享 | §5.7 分享 |
| 17 | `opencode-ecosystem.md` | 生态系统 | §19 插件和生态 |
| 18 | `opencode-rules.md` | 规则系统 (AGENTS.md) | §3.5 规则 |
| 19 | `opencode-plugins.md` | 插件系统 | §19.1-19.4 插件 |
| 20 | `opencode-commands.md` | 自定义命令 | §14.1-14.3 自定义命令 |
| 21 | `opencode-ide-integration.md` | IDE 集成 | §11 IDE 里怎么用 |

---

## Concepts（概念文档，19 个）

| # | 文件名 | 主题 | 对应手册章节 |
|---|--------|------|-------------|
| 1 | `opencode-configuration-guide.md` | 配置详解 | §3 怎么配 |
| 2 | `opencode-tui-guide.md` | TUI 详解 | §5 TUI 怎么用 |
| 3 | `opencode-agents-guide.md` | 代理指南 | §7 代理是什么 |
| 4 | `opencode-models-providers.md` | 模型提供商 | §6 模型怎么选 |
| 5 | `opencode-mcp-integration.md` | MCP 集成 | §9 MCP 扩展 |
| 6 | `opencode-github-integration.md` | GitHub 集成 | §10 GitHub 自动化 |
| 7 | `opencode-custom-commands.md` | 自定义命令 | §14.1-14.3 自定义命令 |
| 8 | `opencode-custom-tools.md` | 自定义工具 | §14.4 自定义工具 |
| 9 | `opencode-acp-support.md` | ACP 协议支持 | §11.4-11.6 IDE |
| 10 | `opencode-web-interface.md` | Web 界面 | §12 Web 界面 |
| 11 | `opencode-session-sharing.md` | 会话分享 | §5.7 分享 |
| 12 | `opencode-agent-skills.md` | Agent Skills | §15 Agent Skills |
| 13 | `opencode-ecosystem-overview.md` | 生态概览 | §19.5 社区资源 |
| 14 | `opencode-plugins-guide.md` | 插件指南 | §19.1-19.4 插件 |
| 15 | `opencode-installation-quickstart.md` | 快速开始 | §2 怎么装 |
| 16 | `opencode-enterprise-deployment.md` | 企业部署 | §18 企业怎么用 |
| 17 | `opencode-sdk-usage.md` | SDK 使用 | §20 SDK 开发 |
| 18 | `opencode-ide-integration.md` | IDE 集成 | §11 IDE 里怎么用 |
| 19 | `opencode-configuration-guide.md` | 配置指南 | §3 怎么配 |

---

## Raw Articles（原始文章，37 个）

位于 `~/wiki/raw/articles/`，为上述 Entities 和 Concepts 的原始 Markdown 来源。

---

## 缺失/待补充项

| 主题 | 状态 | 备注 |
|------|------|------|
| Oh My Opencode 多代理编排 | ⚠️ 简略 | wiki 中有 `oh-my-opencode-orchestration.md` 但手册仅附录提及 |
| 会话压缩（compaction） | ⚠️ 简略 | 只在 §5.3 和 §16.5 提及，无独立章节 |
| 快照与撤销（snapshot/undo） | ⚠️ 简略 | 只在 §3.3 和 §5.3 提及 |
| 多会话管理 | ⚠️ 简略 | 只在 §4.3 和 §12.3 提及 |
