---
name: opencode
description: Delegate coding tasks to OpenCode CLI agent for feature implementation, refactoring, PR review, and long-running autonomous sessions. Requires the opencode CLI installed and authenticated.
version: 1.2.0
author: Hermes Agent
license: MIT
metadata:
  hermes:
    tags: [Coding-Agent, OpenCode, Autonomous, Refactoring, Code-Review]
    related_skills: [claude-code, codex, hermes-agent, opencode-manual]
    references: [references/wiki-index.md]
---

# OpenCode CLI

Use [OpenCode](https://opencode.ai) as an autonomous coding worker orchestrated by Hermes terminal/process tools. OpenCode is a provider-agnostic, open-source AI coding agent with a TUI and CLI.

## When to Use

- User explicitly asks to use OpenCode
- You want an external coding agent to implement/refactor/review code
- You need long-running coding sessions with progress checks
- You want parallel task execution in isolated workdirs/worktrees

## Prerequisites

- OpenCode installed: `npm i -g opencode-ai@latest` or `brew install anomalyco/tap/opencode`
- Auth configured: `opencode auth login` or set provider env vars (OPENROUTER_API_KEY, etc.)
- Verify: `opencode auth list` should show at least one provider
- Git repository for code tasks (recommended)
- `pty=true` for interactive TUI sessions

## Binary Resolution (Important)

Shell environments may resolve different OpenCode binaries. If behavior differs between your terminal and Hermes, check:

```
terminal(command="which -a opencode")
terminal(command="opencode --version")
```

If needed, pin an explicit binary path:

```
terminal(command="$HOME/.opencode/bin/opencode run '...'", workdir="~/project", pty=true)
```

## One-Shot Tasks

Use `opencode run` for bounded, non-interactive tasks:

```
terminal(command="opencode run 'Add retry logic to API calls and update tests'", workdir="~/project")
```

Attach context files with `-f`:

```
terminal(command="opencode run 'Review this config for security issues' -f config.yaml -f .env.example", workdir="~/project")
```

Show model thinking with `--thinking`:

```
terminal(command="opencode run 'Debug why tests fail in CI' --thinking", workdir="~/project")
```

Force a specific model:

```
terminal(command="opencode run 'Refactor auth module' --model openrouter/anthropic/claude-sonnet-4", workdir="~/project")
```

## Interactive Sessions (Background)

For iterative work requiring multiple exchanges, start the TUI in background:

```
terminal(command="opencode", workdir="~/project", background=true, pty=true)
# Returns session_id

# Send a prompt
process(action="submit", session_id="<id>", data="Implement OAuth refresh flow and add tests")

# Monitor progress
process(action="poll", session_id="<id>")
process(action="log", session_id="<id>")

# Send follow-up input
process(action="submit", session_id="<id>", data="Now add error handling for token expiry")

# Exit cleanly — Ctrl+C
process(action="write", session_id="<id>", data="\x03")
# Or just kill the process
process(action="kill", session_id="<id>")
```

**Important:** Do NOT use `/exit` — it is not a valid OpenCode command and will open an agent selector dialog instead. Use Ctrl+C (`\x03`) or `process(action="kill")` to exit.

### TUI Keybindings

| Key | Action |
|-----|--------|
| `Enter` | Submit message (press twice if needed) |
| `Tab` | Switch between agents (build/plan) |
| `Ctrl+P` | Open command palette |
| `Ctrl+X L` | Switch session |
| `Ctrl+X M` | Switch model |
| `Ctrl+X N` | New session |
| `Ctrl+X E` | Open editor |
| `Ctrl+C` | Exit OpenCode |

### Resuming Sessions

After exiting, OpenCode prints a session ID. Resume with:

```
terminal(command="opencode -c", workdir="~/project", background=true, pty=true)  # Continue last session
terminal(command="opencode -s ses_abc123", workdir="~/project", background=true, pty=true)  # Specific session
```

## Common Flags

| Flag | Use |
|------|-----|
| `run 'prompt'` | One-shot execution and exit |
| `--continue` / `-c` | Continue the last OpenCode session |
| `--session <id>` / `-s` | Continue a specific session |
| `--agent <name>` | Choose OpenCode agent (build or plan) |
| `--model provider/model` | Force specific model |
| `--format json` | Machine-readable output/events |
| `--file <path>` / `-f` | Attach file(s) to the message |
| `--thinking` | Show model thinking blocks |
| `--variant <level>` | Reasoning effort (high, max, minimal) |
| `--title <name>` | Name the session |
| `--attach <url>` | Connect to a running opencode server |

## Procedure

1. Verify tool readiness:
   - `terminal(command="opencode --version")`
   - `terminal(command="opencode auth list")`
2. For bounded tasks, use `opencode run '...'` (no pty needed).
3. For iterative tasks, start `opencode` with `background=true, pty=true`.
4. Monitor long tasks with `process(action="poll"|"log")`.
5. If OpenCode asks for input, respond via `process(action="submit", ...)`.
6. Exit with `process(action="write", data="\x03")` or `process(action="kill")`.
7. Summarize file changes, test results, and next steps back to user.

## PR Review Workflow

OpenCode has a built-in PR command:

```
terminal(command="opencode pr 42", workdir="~/project", pty=true)
```

Or review in a temporary clone for isolation:

```
terminal(command="REVIEW=$(mktemp -d) && git clone https://github.com/user/repo.git $REVIEW && cd $REVIEW && opencode run 'Review this PR vs main. Report bugs, security risks, test gaps, and style issues.' -f $(git diff origin/main --name-only | head -20 | tr '\n' ' ')", pty=true)
```

## Parallel Work Pattern

Use separate workdirs/worktrees to avoid collisions:

```
terminal(command="opencode run 'Fix issue #101 and commit'", workdir="/tmp/issue-101", background=true, pty=true)
terminal(command="opencode run 'Add parser regression tests and commit'", workdir="/tmp/issue-102", background=true, pty=true)
process(action="list")
```

## Session & Cost Management

List past sessions:

```
terminal(command="opencode session list")
```

Check token usage and costs:

```
terminal(command="opencode stats")
terminal(command="opencode stats --days 7 --models anthropic/claude-sonnet-4")
```

## Pitfalls

- Interactive `opencode` (TUI) sessions require `pty=true`. The `opencode run` command does NOT need pty.
- `/exit` is NOT a valid command — it opens an agent selector. Use Ctrl+C to exit the TUI.
- PATH mismatch can select the wrong OpenCode binary/model config.
- If OpenCode appears stuck, inspect logs before killing:
  - `process(action="log", session_id="<id>")`
- Avoid sharing one working directory across parallel OpenCode sessions.
- Enter may need to be pressed twice to submit in the TUI (once to finalize text, once to send).

## Verification

Smoke test:

```
terminal(command="opencode run 'Respond with exactly: OPENCODE_SMOKE_OK'")
```

Success criteria:
- Output includes `OPENCODE_SMOKE_OK`
- Command exits without provider/model errors
- For code tasks: expected files changed and tests pass

## Rules

1. Prefer `opencode run` for one-shot automation — it's simpler and doesn't need pty.
2. Use interactive background mode only when iteration is needed.
3. Always scope OpenCode sessions to a single repo/workdir.
4. For long tasks, provide progress updates from `process` logs.
5. Report concrete outcomes (files changed, tests, remaining risks).
6. Exit interactive sessions with Ctrl+C or kill, never `/exit`.

## Knowledge Base

### Primary Reference

The comprehensive OpenCode Chinese operation manual is maintained as a separate skill:

> **`skill_view(name='opencode-manual')`** — v2.0.0, 21 章节 + 附录，32KB+，覆盖安装、配置、CLI、TUI、Agents、工具、MCP、GitHub、Hermes 集成、自定义命令/工具、Agent Skills、常见问题、企业部署、插件生态、SDK 开发、对比分析
>
> **写作风格**：通俗易懂，口语化中文，每节先给结论再给细节，代码示例带注释，配置项给推荐值。

本 SKILL.md 提供 Hermes 调用模板和快捷命令，详细操作参考 `opencode-manual`。

### Wiki 知识库

`~/wiki/opencode/` 包含 77 个文档，分为三类：

| 类型 | 路径 | 数量 | 用途 |
|------|------|------|------|
| Entities | `~/wiki/entities/` | 21 个 | 实体参考（安装、CLI、TUI、模型、代理、权限、LSP、SDK、企业、分享、生态、规则、插件、命令、IDE） |
| Concepts | `~/wiki/concepts/` | 19 个 | 概念指南（配置详解、MCP 集成、插件系统、自定义工具/命令、ACP、Web 界面、Agent Skills、企业部署、SDK 使用、IDE 集成） |
| Raw Articles | `~/wiki/raw/articles/` | 37 个 | 原始 Markdown 来源 |

详见 `references/wiki-index.md`（含 21 个 Entities + 19 个 Concepts + 37 个 Raw Articles 的完整映射表，以及缺失/待补充项清单）。

### 文档映射

本 SKILL.md 各章节对应 wiki 文件：

| SKILL.md 章节 | 主要 wiki 来源 |
|--------------|---------------|
| Prerequisites | `opencode-installation.md`, `opencode.md` |
| One-Shot Tasks | `opencode-cli-commands.md` |
| Interactive Sessions | `opencode-tui.md`, `opencode-tui-guide.md` |
| Common Flags | `opencode-cli-commands.md` |
| PR Review Workflow | `opencode-github.md`, `opencode-github-integration.md` |
| Parallel Work Pattern | `opencode-agents.md`, `opencode-agents-guide.md` |
| Session & Cost Management | `opencode.md` |
| Pitfalls | `opencode-tui.md`, `opencode-configuration.md` |
| Knowledge Base | `opencode.md` + 全部 wiki |
| Oh My Opencode | `~/wiki/concepts/oh-my-opencode-orchestration.md` |

详见 `references/wiki-index.md`（含 21 个 Entities + 19 个 Concepts + 37 个 Raw Articles 的完整映射表，以及缺失/待补充项清单）。

## Oh My Opencode (Multi-Agent Orchestration)

Oh My Opencode (`oh-my-openagent`) is a community plugin that transforms OpenCode into a multi-agent engineering system with 11 specialized agents and 8 task categories. See `~/wiki/opencode/concepts/oh-my-opencode-orchestration.md` for details.

Key agents:
- **Sisyphus**: Main orchestrator (Claude/Kimi/GLM)
- **Hephaestus**: GPT-native deep worker (GPT-5.3-Codex only)
- **Prometheus**: Strategic planning (dual-prompt: Claude ~1100 lines / GPT ~121 lines)
- **Atlas**: Todo orchestration (dual-prompt)
- **Oracle, Librarian, Explore**: Read-only subagents

Key commands:
- `ultrawork` — Fully automatic task execution
- `/start-work` — Prometheus planning mode
- `/init-deep` — Generate hierarchical AGENTS.md files
