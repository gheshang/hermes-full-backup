---
name: daily-self-audit
description: 每日自主审核与优化流程 — 分三层：自动执行（缓存/cron清理）、需确认（memory/skill变更）、砍掉做不到的。cron定时触发，报告+执行合一。
version: 4.0.0
author: 上河一号
metadata:
 hermes:
 tags: [cron, audit, memory, skills, optimization, self-review]
 priority: normal
---

# 每日自审与优化 v2

## 核心设计原则

1. **分层执行，不是只报不做** — 能自动做的直接做，需要确认的才报
2. **砍掉做不到的** — 不在cron场景下搞语义分析、仓库更新决策
3. **时间硬约束** — 凌晨2:30启动，4:00前交付（压缩窗口，倒逼精简）
4. **备份优先于二次验证** — 防误删靠快照，不靠LLM自检
5. **结构优先于语义** — cron场景下只做结构化判断（长度/相同子串/日期），不做语义相似度
6. **深浅分离** — 每日浅审做结构巡检，每周深度审做语义分析，不在同一个cron里混合

## 架构：5个独立Cron任务（v4拆分）

旧版单cron任务因prompt过重（7维度扫描+反向验证+逐一skill_view），导致模型在时限内跑不完，连续3天空输出失败。v4拆为5个独立cron，每个只干一件事，失败不连坐。

| 时间 | 任务名 | 工具集 | 职责 |
|------|--------|--------|------|
| 02:30 | 自审-备份快照 | terminal | cp备份文件，纯shell |
| 02:35 | 自审-缓存清理 | terminal | find -delete，纯shell |
| 02:40 | 自审-Cron健康检查 | terminal | 读cron状态+日志，判断error类型 |
| 02:45 | 自审-Memory检查 | terminal+skill | 读MEMORY.md/USER.md+容量计算+自动压缩 |
| 02:50 | 自审-Skills+Config检查 | terminal+skill | 查skill文件存在性+配置审计 |

关键设计：
- 前2个纯shell，几乎不可能失败
- 每个任务间隔5分钟，避免资源争抢
- 各任务独立交付报告，一个挂不影响其他
- 保留 manual 模式：用户说"自审"/"深度自审"时，本skill仍作为完整流程指南使用

## 手动执行流程（用户说"自审"时触发）

### Layer 0：备份快照（自动执行）

```bash
DATE=$(date +%Y-%m-%d)
mkdir -p ~/.hermes/backups/$DATE
# Memory 存储为 markdown 文件
cp ~/.hermes/memories/MEMORY.md ~/.hermes/backups/$DATE/MEMORY.md 2>/dev/null
cp ~/.hermes/memories/USER.md ~/.hermes/backups/$DATE/USER.md 2>/dev/null
# Skills 目录
cp -r ~/.hermes/skills/ ~/.hermes/backups/$DATE/skills/ 2>/dev/null
# 配置
cp ~/.hermes/config.yaml ~/.hermes/backups/$DATE/config.yaml 2>/dev/null
cp ~/.hermes/SOUL.md ~/.hermes/backups/$DATE/SOUL.md 2>/dev/null
echo "备份完成: ~/.hermes/backups/$DATE/"
```

### Layer 1：自动执行（做了就报，不问）

#### 1.0 磁盘检查（最优先，放缓存清理之前）
```bash
USE_PCT=$(df / | tail -1 | awk '{print $5}' | tr -d '%')
REMAIN_KB=$(df / | tail -1 | awk '{print $4}')
echo "磁盘: ${USE_PCT}% 使用，剩余 ${REMAIN_KB}KB"
if [ "$USE_PCT" -gt 90 ]; then
  echo "🚨 磁盘使用超90%！紧急清理 uv 缓存："
  du -sh ~/.cache/uv/ 2>/dev/null
  find ~/.cache/uv -maxdepth 1 -name ".tmp*" -type d | wc -l
  echo "执行: uv cache clean && find ~/.cache/uv -maxdepth 1 -name '.tmp*' -type d -exec rm -rf {} +"
  uv cache clean 2>/dev/null
  find ~/.cache/uv -maxdepth 1 -name ".tmp*" -type d -exec rm -rf {} + 2>/dev/null
  echo "清理后: $(df -h / | tail -1)"
elif [ "$USE_PCT" -gt 80 ]; then
  echo "⚠️ 磁盘使用超80%，清理 uv .tmp 残留："
  find ~/.cache/uv -maxdepth 1 -name ".tmp*" -type d -exec rm -rf {} + 2>/dev/null
  du -sh ~/.cache/uv/ 2>/dev/null
fi
```
**注意**：磁盘检查必须在所有操作之前执行，因为磁盘满会导致后续备份和所有操作失败。

#### 1.1 缓存清理
```bash
# 查大小
du -sh ~/.hermes/audio_cache/ ~/.hermes/image_cache/ ~/.hermes/cron/output/ 2>/dev/null
# 清7天前的缓存
find ~/.hermes/audio_cache/ -mtime +7 -delete 2>/dev/null
find ~/.hermes/image_cache/ -mtime +7 -delete 2>/dev/null
find ~/.hermes/cron/output/ -mtime +7 -delete 2>/dev/null
# 报清理后大小
du -sh ~/.hermes/audio_cache/ ~/.hermes/image_cache/ ~/.hermes/cron/output/ 2>/dev/null
```

### Layer 1.2：过期Cron清理 + 自愈
- `cronjob action=list` 获取全部任务
- 一次性任务且 next_run 已过期（过去的时间）→ 直接 remove
- 状态为 paused 的任务 → 列入报告建议删除（无法判断暂停了多久，需用户确认）
- 对每个任务检查 `last_status`：
  - `last_status == "error"` → 读取 `~/.hermes/cron/output/<job_id>/` 最近日志判断类型
  - 连续 3 次 error → 报告中 **加粗告警** 🚨
  - 检查 `next_run_at` 是否在合理范围内

#### 1.3 过期备份清理
```bash
# 保留最近15天备份，删更早的（加 -mindepth 1 防止删 backups 目录本身）
find ~/.hermes/backups/ -mindepth 1 -maxdepth 1 -mtime +15 -type d -exec rm -rf {} + 2>/dev/null
```

#### 1.4 孤儿Cron输出目录清理
- 获取所有活跃任务ID：`cronjob action=list | jq -r '.[] | select(.status=="active") | .id'`
- 扫描 `~/.hermes/cron/output/` 下所有子目录
- 子目录名不在活跃任务ID列表中 → **孤儿目录**，需确认删除
- **注意**：孤儿目录可能是已删除任务的残留输出，删除前检查最近日志日期，确认无近期活动再删除

### Layer 2：需确认（只报建议，附操作命令）

#### 2.1 Memory 审计
- 用 memory 工具读取当前所有条目
- **⚠️ 关键：批量操作禁止用 memory 工具** — `memory action=remove/replace` 用`old_text`子串匹配，短文本可能误伤含相同子串的其他条目。批量操作时改用 `write_file` 直接覆盖 `~/.hermes/memories/MEMORY.md`。详情见 `references/memory-tool-pitfall.md`。
- **占用 > 80% 时触发自动压缩**（纯结构化规则，零语义判断）：
 - **去重优先**：合并后新旧条目共存（新旧都含相同关键信息）→ 删旧条目（如合并Wiki条目后旧条目仍残留）→ 省字最多、风险最低
 - 同一信息分散在多条 → 合并为一条（如CC Switch分两条记 → 合一条）
 - 单条 > 300 字符 → 自动压缩（删冗余措辞，保留事实断言）
 - 两条含完全相同子串 > 40 字符 → 自动合并（保留更完整版本）
 - 含明确过期日期且日期已过 14 天 → 自动移除
 - 其他疑似重复但表述不同的条目 → **不动，留给深度审处理**（宁占位不误删）
 - 自动压缩每条节省 < 30 字符的不动（不值得冒风险）
 - **压缩前必须先备份**：`cp ~/.hermes/memories/MEMORY.md ~/.hermes/memories/MEMORY.md.bak`（同理USER.md）
 - 压缩后在报告中列出"已自动压缩 N 条，释放 X 字符"
- **占用 ≤ 80% 时走旧模式**（只报建议，附可复制命令）：
  - 字符数占比 > 容量70% → 报警并建议压缩方案
  - 明确冲突：两条含相反断言 → 标记"待裁决"
  - 条目含日期且日期已过7天 → 标记"疑似过时"
- 每条建议附可直接执行的 `memory` 命令格式，用户复制粘贴即可

#### 2.2 Skills 审计
- `skills_list` 获取列表
- **结构检查 + 健康评分**（每项得分叠加）：

| 检查项 | 分值 | 方法 |
|--------|------|------|
| SKILL.md 存在且非空 | +1 | read_file |
| description 与 name 不矛盾 | +1 | 字符串包含检查 |
| 引用文件（references/templates/scripts）存在 | +1 | read_file 验证 |
| metadata.tags 非空 | +0.5 | YAML 解析 |
| 最近 30 天被 skill_view 加载过 | +1 | 检查 cron output 日志 |

- 总分 < 2 的 skill → 标记"退化风险"，建议 review 或删除
- 不逐一 skill_view 深度审（太慢），只在深度审模式时才做

#### 2.3 配置审计
- `hermes config list` 查配置
- 检查 SOUL.md 是否存在且非空
- 检查已废弃的模型配置（模型名含 "deprecated" 或已知的下线模型）
- **config.yaml 完整性检查**（防止被意外覆盖/精简）：
  - 对比 `~/.hermes/config.yaml` 与 `~/.hermes/config.yaml.bak` 的行数和字节数
  - 当前文件比 bak 少超过 20% → **红色告警**，提示用户 `cp config.yaml.bak config.yaml` 恢复
  - 检查关键段是否存在：`platforms`、`custom_providers`、`model`、`memory`
  - 若 `.bak` 不存在，提醒用户手动创建备份：`cp config.yaml config.yaml.bak`
- 不做语义偏移分析（cron场景下无参照）

#### 2.4 Hindsight 一致性检查（已废弃）

Hindsight 已于 2026-06-23 完全卸载（Python 包、配置/数据目录、pg0 PostgreSQL 实例、CLI 二进制、skill 均已删除）。此检查项不再执行。若将来需要第三方长期记忆系统，可重新部署后恢复此节。

### Layer 3：已砍掉（不做，别装能做到）

| 维度 | 砍掉原因 |
|------|----------|
| 交互模式/重复踩坑分析 | cron无上下文，session_search关键词匹配不是语义分析，抓不到"模式" |
| 外部仓库更新检查 | 克隆的数据源仓库，上游变动不影响本地已有内容，pull/merge需人工决策 |
| Skill深度内容审查 | 30+个skill逐一view耗时过长，且cron无法判断内容质量 |
| 反向验证轮 | 同模型两轮自检不提升置信度，备份快照比二次推理可靠 |

## 报告格式

```
## 自审报告 YYYY-MM-DD

### ✅ 已自动执行
- 缓存清理：释放约 X MB（audio X MB / image X MB / cron X MB）
- Cron清理：删除 N 个过期任务（[任务名列表]）
- 备份快照：已保存至 ~/.hermes/backups/YYYY-MM-DD/
- 过期备份清理：删除 N 天前的备份

### ⚠️ 待你确认（复制命令即可执行）
- Memory：N条建议
  - [压缩方案] → `memory action="replace" target="memory" old_text="..." new_text="..."`
  - [合并方案] → `memory action="remove" target="memory" old_text="..."`
- Skills：N条问题
  - [引用断裂] → `skill_manage action="patch" name="xxx" ...`
- 配置：N条问题
  - [具体描述]

### ℹ️ 状态概览
- Memory：N条 / 容量 X%
- Skills：N个
- Cron：N个活跃任务
- 缓存：约 X MB

---

## Pitfalls（血泪教训，详见"已知陷阱"段）

- YAML缩进修复、cron投递报错排查、config对比方法 → 见"已知陷阱"#5/#6
- **memory工具操作陷阱** → 见"已知陷阱"#9，详情见 `references/memory-tool-pitfall.md`
- **自审结果执行陷阱** → 见"已知陷阱"#10/#11，详情见 `references/self-audit-execution-pitfall.md`
- **关键补充**：排查cron投递报错时，先确认任务本身`last_status`是否ok——任务执行和投递是两个独立环节，任务成功但投递失败≠任务逻辑有问题
```

## 已知陷阱

1. **单cron大prompt必死** — LLM在cron场景下处理7维度扫描+反向验证+逐一skill_view会超时空输出，已验证连续3天失败
2. **cron日志的"No response generated"** — 不是输出为空，是模型根本没产出任何内容（被超时或model error杀掉）
3. **备份快照必须在所有操作之前** — 没备份不做任何操作，包括自动压缩。备份范围包括MEMORY.md/USER.md/SOUL.md/config.yaml，不只是config.yaml
4. **Memory压缩宁保守不误删** — 疑似重复但表述不同的条目不动，留给深度审处理
5. **cron投递 `failed to load gateway config: string indices must be integers`** — 这是 `gateway/config.py:load_gateway_config()` 的TypeError，config.yaml某字段被解析为字符串而非dict（通常是YAML被sed/patch/write_file误覆盖导致platforms段结构异常）。排查步骤：(1) 对比config.yaml与.bak字节数，差异>20%说明被覆写；(2) 用gateway的venv python跑 `python3 -c "from gateway.config import load_gateway_config; load_gateway_config()"` 复现traceback定位坏字段；(3) 恢复正确config后手动 `cronjob run` 清除last_delivery_error。**不要盲目改YAML缩进**
6. **YAML缩进修改 = 翻车高发区** — sed/patch/Python手动拼接对YAML缩进的处理极不可靠（连续3次搞炸config.yaml）。唯一可靠方案：`ruamel.yaml`（`pip install ruamel.yaml`），它保持原格式只改数据。如果必须手动改，先用 `cat -An` 看精确空格数，再用Python逐行替换前缀空格
7. **write_file覆盖MEMORY.md/USER.md前必须备份** — write_file是全量覆盖，内容丢失无法撤销。修改这些文件前先`cp 为.bak`
8. **Cron输出目录孤儿残留** — `~/.hermes/cron/output/<job_id>/` 目录可能因任务删除而残留。清理时需对比活跃任务ID列表，不在列表中的目录为孤儿。删除前检查最近日志日期确认无近期活动。
9. **memory工具remove/replace的substring匹配陷阱** — `memory action=remove/replace` 用`old_text`子串匹配，短文本可能误伤含相同子串的其他条目。批量操作时**禁止用memory工具**，改用`write_file`直接覆盖`~/.hermes/memories/MEMORY.md`全量写入。压缩前先`cp`备份。
10. **自审结果未落地为文件** — 自审cron的输出只存在于session历史中，没有持久化到文件。用户要求"查看自审记录"时需通过`session_search`检索，而非直接读文件。**修复方案**：自审cron任务应在`~/.hermes/cron/output/`中输出结构化报告文件（如`audit-YYYY-MM-DD.md`），便于后续查阅和交叉验证。
11. **执行自审建议前必须先读完整审计结果** — 自审cron输出的建议列表（如"MEMORY.md第一条需精简"）必须完整读取后再行动，不能凭记忆或部分印象就批量操作。本次事故：自审只点名MEMORY.md第一条+OpenCode CLI重复，但代理擅自精简了USER.md的4条。**规则**：自审报告中的每一条建议都要逐项核对，未提及的条目不得修改。
12. **自审结果执行边界** — 自审报告只点名N条，就是硬边界。超出边界=越权。宁可保守，不可越界。恢复误改条目时，需对照自审原始报告逐项确认，不能凭印象恢复。

## Cron拆分架构（v4 更新）

**核心教训**：单一大型 cron 任务（7维度全量扫描+反向验证）会导致模型超时空输出。拆为多个小任务，失败不连坐。

| 时间 | 任务 | 工具集 | 干什么 |
|------|------|--------|--------|
| 02:30 | 自审-备份快照 | terminal | cp 文件，纯 shell |
| 02:35 | 自审-缓存清理 | terminal | find -delete，纯 shell |
| 02:40 | 自审-Cron健康检查 | terminal | 读 cron 状态 + 日志 |
| 02:45 | 自审-Memory检查 | terminal + skill | 读文件 + 容量计算 + 压缩 |
| 02:50 | 自审-Skills+Config检查 | terminal + skill | 查 skill 文件存在性 + 配置 |

- 所有任务 deliver 到飞书（`feishu`），用户在飞书机器人查看结果
- 每个 prompt 尽量写死 bash 命令，减少 LLM 决策量
- 纯 shell 任务（备份/清理）几乎不可能失败
- 5 分钟间隔，单独跑单独报

## Cron拆分后的关键规则

1. **5任务串行依赖** — 备份必须在缓存清理之前完成（02:30 < 02:35），Memory检查依赖备份兜底
2. **Layer 1 直接做** — 缓存清理、过期备份清理可逆，不需要确认
3. **Layer 2 只报不做** — Memory自动压缩仅在>80%时触发，且有备份兜底
4. **Cron健康检查是自检** — 检查包括自身在内的所有cron任务
5. **备份保留15天** — 超过15天的备份自动清理
6. **容量预警线** — Memory占用超过70%时报告加粗提醒


