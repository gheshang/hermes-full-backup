---
name: vps-python-dev-env
description: >-
  Set up a Python practice/learning environment on a headless VPS, including
  Jupyter Notebook with remote access via SSH tunnel or ngrok — especially
  for users accessing from mobile devices (Android tablet, iPad, etc.).
version: 1.1.0
author: 上河一号
metadata:
  hermes:
    tags: [vps, python, jupyter, ngrok, remote-access, dev-environment]
    category: devops
---

# VPS Python 开发环境搭建指南

用于在无公网端口开放的 VPS 上搭建可远程访问的 Python 练习环境 + Jupyter Notebook，支持从手机/平板等设备访问。

---

## 快速搭建流程

### 1. 创建工作目录 + 虚拟环境

```bash
mkdir -p ~/python-practice
python3 -m venv ~/python-practice/.venv
```

### 2. 安装常用包

```bash
~/python-practice/.venv/bin/pip install requests beautifulsoup4 pandas pytest jupyter
```

### 3. 启动 Jupyter

```bash
cd ~/python-practice && ~/python-practice/.venv/bin/jupyter notebook \
  --no-browser --ip=0.0.0.0 --port=8888
```

启动后在终端中找到 token URL：

```
http://127.0.0.1:8888/tree?token=<一串hash>
```

### 4. 后台运行（daemon 模式）

```bash
cd ~/python-practice
nohup ~/python-practice/.venv/bin/jupyter notebook \
  --no-browser --ip=0.0.0.0 --port=8888 > /dev/null 2>&1 &
```

## 远程访问方法

### 方法 A：SSH 隧道（推荐，含 autossh）

**适合有终端的环境（电脑、Termux）。** 不需要暴露端口到公网。

```bash
# 基础版
ssh -f -N -L 8888:localhost:8888 user@server-ip

# autossh（自动重连）
autossh -M 0 -f -N -L 8888:localhost:8888 user@server-ip
```

参数说明：
- `-f` → fork 到后台，关终端不中断
- `-N` → 只转发不执行命令（隧道专用）
- `-L a:b:c:d` → 本机 a 端口 → 远程 c 端口
- `-M 0` → autossh 用自己的心跳（不占端口）

**SSH config 快捷方式（~/.ssh/config）：**

```
Host pydev
    HostName server-ip
    User username
    LocalForward 8888 localhost:8888
```

之后只需 `ssh pydev`（加 `-f -N` 就是后台）。

**管理 SSH 隧道：**

```bash
# 看是否活着
ps aux | grep 'ssh.*8888'

# 关掉
ssh -O exit user@server-ip
# 或
pkill -f 'ssh.*8888.*localhost'
```

### 方法 B：ngrok（适合安卓平板 / iPad / 无终端的设备）

ngrok 把 VPS 的 Jupyter 端口暴露成一个公网 HTTPS URL，浏览器直接打开。

**在 VPS 上安装 ngrok：**

```bash
# 下载安装
cd /tmp
curl -sLO https://bin.equinox.io/c/bNyj1mQVY4c/ngrok-v3-stable-linux-amd64.tgz
tar xzf ngrok-v3-stable-linux-amd64.tgz
mkdir -p ~/.local/bin && cp ngrok ~/.local/bin/

# 配置 authtoken（需要注册 https://dashboard.ngrok.com/signup）
# 登录后进 https://dashboard.ngrok.com/get-started/your-authtoken 复制 token
~/.local/bin/ngrok config add-authtoken <你的token>

# 启动隧道（把 VPS 8888 端口映射出去）
~/.local/bin/ngrok http 8888
```

启动后 ngrok 终端会打印 public URL：

```
Forwarding  https://xxxx.ngrok-free.app -> http://localhost:8888
```

用这个 HTTPS URL 打开即是 Jupyter。

**后台运行 ngrok：**

```bash
nohup ~/.local/bin/ngrok http 8888 --log=stdout > ~/ngrok.log 2>&1 &
```

查看 URL（不需要再看终端）：

```bash
curl -s http://127.0.0.1:4040/api/tunnels | python3 -c "import sys,json; print(json.load(sys.stdin)['tunnels'][0]['public_url'])"
```

**停止 ngrok：**

```bash
pkill ngrok
```

### 方法 C：云平台安全组开放端口（不推荐）

大多数云 VPS 的防火墙在平台层（安全组），不光在服务器内。如果非要直接暴露 8888 端口，需要去云控制台放行该端口的入站规则。

**不推荐的原因：** 直接暴露会增加安全风险，token 泄露则任何人可访问 Jupyter。

### 方法 D：Cloudflare Tunnel（推荐，国内访问优先）

当用户在中国大陆、服务器在境外时，ngrok 绕美国延迟高（300~500ms），Cloudflare Tunnel 借助亚太边缘节点（香港/新加坡/东京），延迟 50~100ms。

**原理：** 服务器主动连 Cloudflare 边缘节点，不暴露任何入站端口。用户通过域名经 Cloudflare 访问。

**前置条件：** 一个域名（.xyz/.top 首年 ¥6~¥20，国外 Namecheap/Cloudflare Registrar 买不需要实名）。

**安装 cloudflared（在 VPS 上）：**

```bash
cd /tmp
curl -sLO https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-amd64
chmod +x cloudflared-linux-amd64
mkdir -p ~/.local/bin && mv cloudflared-linux-amd64 ~/.local/bin/cloudflared
```

**配置 Tunnel（在 VPS 上一次性操作）：**

```bash
# 1. 登录（浏览器打开 URL 授权你的 Cloudflare 账号）
~/.local/bin/cloudflared tunnel login

# 2. 创建隧道
~/.local/bin/cloudflared tunnel create jupyter-tunnel

# 3. 配置 DNS（隧道 ID 会在上一步打印，形如 <uuid>）
~/.local/bin/cloudflared tunnel route dns <tunnel-id> jupyter.你的域名.com

# 4. 启动隧道连接 Jupyter
~/.local/bin/cloudflared tunnel run --url http://127.0.0.1:8888 <tunnel-id>
```

之后访问 `https://jupyter.你的域名.com` 即可直达 Jupyter。

**后台运行：**

```bash
~/.local/bin/cloudflared tunnel run --url http://127.0.0.1:8888 <tunnel-id> > ~/cloudflared.log 2>&1 &
```

**停止：**

```bash
pkill cloudflared
```

---

## 第一件事：诊断端口是否可公网访问

部署完 Jupyter 后不要假设端口通了。先做诊断：

```bash
# 1. OS 防火墙检查
sudo ufw status 2>/dev/null || echo "ufw not active"
sudo iptables -L INPUT -n 2>/dev/null | grep ACCEPT | head -5

# 2. 监听确认
ss -tlnp | grep jupyter || echo "jupyter not listening"

# 3. 公网可达测试（在服务器上测公网 IP 是否通）
PUBLIC_IP=$(curl -s ifconfig.me)
curl -s -o /dev/null -w "%{http_code}" --connect-timeout 5 "http://$PUBLIC_IP:8888/" 2>&1
# 返回 0xx / 空 → hypervisor 防火墙拦截了端口
# 返回 302 → 端口的通，Jupyter 正常响应

# 4. 端口试探：换一个非标准高端口试试
pkill -f jupyter-notebook
cd ~/python-practice && ~/python-practice/.venv/bin/jupyter notebook --no-browser --ip=0.0.0.0 --port=18080
# 还不行？测一下 80/443 是否也被拦
curl -s -o /dev/null -w "%{http_code}" --connect-timeout 5 "http://$PUBLIC_IP:80/" 2>&1
```

```text
诊断结论对照表：
┌────────────────────┬──────────────────────────┐
│ OS端口OK + 公网不通 │ 云厂商 hypervisor 防火墙  │
├────────────────────┼──────────────────────────┤
│ 公网不通（含80/443）│ 安全组挡了所有入站流量     │
├────────────────────┼──────────────────────────┤
│ 公网80/443通，其    │ 安全组只开放了基本端口     │
│ 他不通              │                          │
└────────────────────┴──────────────────────────┘
```

如果诊断结果是"hypervisor 防火墙拦截且没有安全组控制台"，直接走 **方法 D（Cloudflare Tunnel）**。

## 日常操作

| 操作 | 命令 |
|------|------|
| 启动 Jupyter | `nohup ~/python-practice/.venv/bin/jupyter-notebook --no-browser --ip=0.0.0.0 --port=8888 > /dev/null 2>&1 &` |
| 查看是否在运行 | `ss -tlnp \| grep jupyter` |
| 查看 token | `cat ~/.local/share/jupyter/runtime/jpserver-*.html \| grep -oP 'token=\K[a-f0-9]+'` |
| 停止 Jupyter | `pkill -f jupyter-notebook` |
| 装新包 | `~/python-practice/.venv/bin/pip install <包名>` |

## 踩坑记录

| 坑 | 解决 |
|----|------|
| Jupyter 启动后没输出/退出了 | 不要用 `source .venv/bin/activate` 来启动后台进程，直接用 `.venv/bin/jupyter-notebook` 全路径 |
| 端口被占用 | 自动换端口或先 `pkill -f jupyter-notebook` |
| ngrok 提示需要 authtoken | 必须去 ngrok dashboard 注册拿 token，免费版够用 |
| 安卓平板没终端 | 装 Termux（F-Droid 版），跑 SSH 隧道；或用 ngrok 方案 |
| SSH 隧道一关终端就断 | 加 `-f` 参数：`ssh -f -N -L ...` |
| Jupyter token 每次重启都变 | 无法在无交互环境设固定密码；推荐用 SSH 隧道方式（不暴露端口，不需要 token 重复输入） |

## 安全提醒

- **不要**把 Jupyter 的 token 发给不信任的人
- **不要**在 ngrok URL 上输敏感密码（ngrok 免费版是公网可扫的）
- SSH 隧道最安全：不暴露任何端口到公网
- ngrok 次之：HTTPS 加密但 URL 随机，有一定隐蔽性
- 直接开端口最不安全，除非配合 IP 白名单
