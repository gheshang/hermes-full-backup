---
name: jupyter-server-headless
description: >
  Set up and run Jupyter Notebook as a user-facing service on a headless Linux
  VPS. Covers virtual environment creation, package installation, background
  server start, token discovery, port conflict resolution, and firewall check.
  Use when the user wants to access Jupyter from their browser on a remote server
  (no GUI, no X forwarding).
version: 1.1.0
author: Hermes Agent
license: MIT
metadata:
  hermes:
    tags: [jupyter, notebook, headless, vps, python, environment]
    category: devops
---

# Jupyter Server on Headless VPS

Set up Jupyter so the user can open it in their browser from any machine.

## Quick Start (Summary)

```bash
# 1. Create dir + venv
mkdir -p ~/python-practice
python3 -m venv ~/python-practice/.venv

# 2. Install Jupyter + common packages
~/python-practice/.venv/bin/pip install notebook pandas requests beautifulsoup4

# 3. Start (use full binary path, not source activate)
cd ~/python-practice && exec ~/python-practice/.venv/bin/jupyter notebook \
  --no-browser --ip=0.0.0.0 --port=8888 2>&1

# 4. Get token
cat ~/.local/share/jupyter/runtime/jpserver-*.html

# 5. Check firewall
sudo ufw status 2>/dev/null || echo "ufw not active"
```

## Detailed Workflow

### 1. Create Environment

```bash
mkdir -p ~/python-practice
python3 -m venv ~/python-practice/.venv
```

### 2. Install Packages

Always use the venv's pip directly (not `source activate`):

```bash
~/python-practice/.venv/bin/pip install notebook pandas requests beautifulsoup4 pytest jupyter
```

### 3. Start Jupyter Server

Start as a **background process** (the server never exits on its own):

```bash
cd ~/python-practice && exec ~/python-practice/.venv/bin/jupyter notebook \
  --no-browser --ip=0.0.0.0 --port=8888 2>&1
```

Key points:
- `exec` replaces the shell, giving Jupyter PID 1 in the bg process
- Use the **full path** to the venv binary — `source .venv/bin/activate` does NOT work in background processes (non-interactive shell)
- `--no-browser` — no GUI to open
- `--ip=0.0.0.0` — listen on all interfaces so external access works
- `--port=8888` — can change to an available port

### 4. Discover Access Token

Jupyter generates a random token on startup. You cannot see it from the
background process output. Retrieve it from the runtime directory:

```bash
cat ~/.local/share/jupyter/runtime/jpserver-*.html
```

This file contains a redirect page with the full URL including token.

Alternatively, parse it from the HTML:

```bash
grep -oP 'token=\K[a-f0-9]+' ~/.local/share/jupyter/runtime/jpserver-*.html | head -1
```

### 5. Construct Access URL

Replace `0.0.0.0` with the server's public IP:

```bash
PUBLIC_IP=$(curl -s ifconfig.me)
TOKEN=$(grep -oP 'token=\K[a-f0-9]+' ~/.local/share/jupyter/runtime/jpserver-*.html | head -1)
echo "http://$PUBLIC_IP:8888/tree?token=$TOKEN"
```

### 6. Firewall Check

```bash
sudo ufw status 2>/dev/null || echo "ufw not active"
iptables -L INPUT -n --line-numbers 2>/dev/null | grep ACCEPT | head -10
```

### 7. Stop Jupyter

```bash
pkill -f jupyter-notebook
```

## Pitfalls

### ❌ Cloud provider firewall（最常见）

OS 防火墙（ufw/iptables）没有阻挡，但公网仍然打不开 → 云厂商 hypervisor 层的防火墙/安全组拦了。

诊断步骤：

```bash
# 1. OS 防火墙检查
sudo ufw status 2>/dev/null || echo "ufw not active"

# 2. 公网可达测试
PUBLIC_IP=$(curl -s ifconfig.me)
curl -s -o /dev/null -w "%{http_code}" --connect-timeout 5 "http://$PUBLIC_IP:8888/"

# 3. 如果不通，试高端口 + 试 80/443
#    80/443 也不通 → 安全组拦了所有入站
#    80/443 通但 8888 不通 → 安全组只开放基本端口
#    两种情况都需要去云控制台安全组放行端口，或用隧道方案
```

推荐走 **SSH 隧道** 或 **Cloudflare Tunnel**（特别适合中国访问境外 VPS 的场景）。

### ❌ `source .venv/bin/activate` in background processes

Does not work. The activation script modifies shell state (PATH, VIRTUAL_ENV),
which is discarded when the shell exits. ALWAYS use the full venv binary path:

```bash
# DON'T
source .venv/bin/activate && jupyter notebook ...

# DO
~/python-practice/.venv/bin/jupyter notebook ...
```

### ❌ Port already in use

Stale Jupyter processes from previous starts leave ports occupied. Kill first:

```bash
pkill -f jupyter-notebook
sleep 1
ss -tlnp | grep -E '888[0-9]' || echo "ports clear"
```

### ❌ Can't set password non-interactively

`jupyter notebook password` calls `getpass.getpass()` which fails in
non-interactive terminals. Use token-based auth — provide the token URL.

### ❌ Token changes on every restart

Each restart generates a new random token. Always re-read the runtime directory
after start.

### ❌ `jupyter-notebook` not on PATH

When starting via venv, don't rely on PATH. Use the exact path:
`~/python-practice/.venv/bin/jupyter notebook`

## Verification

```bash
ss -tlnp | grep jupyter        # listening?
ls ~/.local/share/jupyter/runtime/jpserver-*.html  # token file exists?
curl -s -o /dev/null -w "%{http_code}" http://127.0.0.1:8888/api  # 403 = alive
```