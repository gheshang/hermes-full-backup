# DOCX 表格技术参考

## 1. OOXML 合并单元格表示

Word 文档 (.docx) 本质是 ZIP 包，内含 XML 文件。表格的合并单元格通过以下元素表示：

### 水平合并（colspan）

```xml
<w:tcPr>
  <w:gridSpan w:val="3"/>  <!-- 跨越3列 -->
</w:tcPr>
```

### 垂直合并（rowspan）

```xml
<w:tcPr>
  <w:vMerge w:val="restart"/>  <!-- 合并开始 -->
  <!-- 后续行的对应单元格 -->
  <w:vMerge/>  <!-- 合并继续 -->
</w:tcPr>
```

## 2. python-docx 检测合并单元格

```python
from docx import Document

doc = Document("file.docx")
table = doc.tables[0]

for row_idx, row in enumerate(table.rows):
    for cell_idx, cell in enumerate(row.cells):
        # 检测是否与前一个单元格合并
        if cell_idx > 0:
            prev_cell = row.cells[cell_idx - 1]
            if cell._tc == prev_cell._tc:
                print(f"单元格 [{row_idx}, {cell_idx}] 与前一个合并")
```

## 3. Aspose.Words 合并单元格检测

```python
import aspose.words as aw

doc = aw.Document("file.docx")
table = doc.tables[0]

for row in table.rows:
    for cell in row.cells:
        # 水平合并状态
        if cell.cell_format.horizontal_merge == aw.tables.CellMerge.FIRST:
            print("水平合并开始")
        elif cell.cell_format.horizontal_merge == aw.tables.CellMerge.PREVIOUS:
            print("水平合并继续")
        
        # 垂直合并状态
        if cell.cell_format.vertical_merge == aw.tables.CellMerge.FIRST:
            print("垂直合并开始")
        elif cell.cell_format.vertical_merge == aw.tables.CellMerge.PREVIOUS:
            print("垂直合并继续")
```

## 4. 常见陷阱

| 陷阱 | 表现 | 解决方案 |
|------|------|----------|
| python-docx 无法区分 colspan/rowspan | `row.cells` 长度不变 | 解析 XML 的 `w:gridSpan` 和 `w:vMerge` |
| Aspose.Words CellMerge 属性失效 | 返回 NONE 即使已合并 | 检查 HTML 输出的 `colspan` 属性 |
| docxtpl 表格行循环失效 | Jinja2 标签不能跨行 | 用 `{% for item in items %}` 在行内 |
| 新表格无样式 | 边框不显示 | 设置 `table.style = 'Table Grid'` |
| 格式丢失 | 字体、颜色丢失 | 用 Aspose.Words 或 docx-format-replicator |

## 5. 推荐工作流

```
1. 用 Word 设计模板 → 插入表格、设置合并单元格、添加合并域
2. 运行 docx_table_inspector.py 诊断结构
3. 选择引擎：
   - 简单填充 → docx-mailmerge
   - 复杂表格 → Aspose.Words
   - Jinja2 模板 → docxtpl
4. 批量生成 → Python 脚本循环处理数据源
```

## 6. 外部资源

- [python-docx tables documentation](https://python-docx.readthedocs.io/en/latest/user/tables.html)
- [python-docx cell merge analysis](https://python-docx.readthedocs.io/en/latest/dev/analysis/features/table/cell-merge.html)
- [Aspose.Words CellMerge documentation](https://reference.aspose.com/words/python/aspose.words.tables/cellformat/horizontalmerge/)
- [docxtpl documentation](https://docxtpl.readthedocs.io/)
- [Stack Overflow: Detecting merged cells](https://stackoverflow.com/questions/39297368/detecting-merged-cells-in-a-word-document-table)