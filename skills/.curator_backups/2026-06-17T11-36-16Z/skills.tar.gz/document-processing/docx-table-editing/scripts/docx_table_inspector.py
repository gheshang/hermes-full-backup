#!/usr/bin/env python3
"""
docx_table_inspector.py - 诊断 docx 文件中的表格结构

用法：python docx_table_inspector.py <file.docx>

输出：
- 表格数量
- 每个表格的行数、列数
- 合并单元格信息（colspan/rowspan）
- 单元格内容预览
"""

import sys
from docx import Document
from docx.oxml.ns import qn
from lxml import etree


def inspect_table(table, table_idx):
    """详细检查一个表格的结构"""
    print(f"\n{'='*60}")
    print(f"表格 #{table_idx + 1}")
    print(f"{'='*60}")
    
    # 基本信息
    rows = table.rows
    cols = len(rows[0].cells) if rows else 0
    print(f"行数: {len(rows)}, 列数: {cols}")
    
    # 表格样式
    style = table.style
    if style:
        print(f"表格样式: {style.name}")
    
    # 检查 XML 中的网格信息
    tbl = table._tbl
    tblPr = tbl.find('.//w:tblPr', {'w': 'http://schemas.openxmlformats.org/wordprocessingml/2006/main'})
    if tblPr is not None:
        tblGrid = tbl.find('.//w:tblGrid', {'w': 'http://schemas.openxmlformats.org/wordprocessingml/2006/main'})
        if tblGrid is not None:
            grid_cols = tblGrid.findall('.//w:gridCol', {'w': 'http://schemas.openxmlformats.org/wordprocessingml/2006/main'})
            print(f"网格列数: {len(grid_cols)}")
    
    # 检查每行的合并情况
    ns = {'w': 'http://schemas.openxmlformats.org/wordprocessingml/2006/main'}
    
    merged_cells = []
    
    for row_idx, row in enumerate(rows):
        row_cells = row.cells
        print(f"\n  行 {row_idx + 1} ({len(row_cells)} 个单元格):")
        
        for cell_idx, cell in enumerate(row_cells):
            # 获取单元格文本
            text = cell.text.strip()[:50] if cell.text else ""
            
            # 检查合并信息
            tcPr = cell._tc.find('w:tcPr', ns)
            
            colspan = 1
            rowspan = 1
            is_merged = False
            
            if tcPr is not None:
                # 检查 gridSpan (colspan)
                grid_span = tcPr.find('w:gridSpan', ns)
                if grid_span is not None:
                    colspan = int(grid_span.get(qn('w:val'), 1))
                
                # 检查 vMerge (rowspan)
                v_merge = tcPr.find('w:vMerge', ns)
                if v_merge is not None:
                    val = v_merge.get(qn('w:val'), 'continue')
                    if val == 'restart':
                        rowspan = "start"
                    else:
                        rowspan = "continue"
                    is_merged = True
            
            # 检查是否是已合并单元格的重复引用
            if cell_idx > 0:
                prev_cell = row_cells[cell_idx - 1]
                if cell._tc == prev_cell._tc:
                    is_merged = True
            
            status = ""
            if colspan > 1:
                status += f" colspan={colspan}"
            if rowspan != 1:
                status += f" rowspan={rowspan}"
            if is_merged:
                status += " [合并]"
            
            print(f"    单元格[{cell_idx}]: {text!r}{status}")
            
            if is_merged or colspan > 1:
                merged_cells.append({
                    'row': row_idx,
                    'col': cell_idx,
                    'colspan': colspan,
                    'rowspan': rowspan,
                    'text': text
                })
    
    # 总结合并单元格
    if merged_cells:
        print(f"\n  ⚠️ 发现 {len(merged_cells)} 个合并单元格:")
        for mc in merged_cells:
            print(f"    行{mc['row']+1}, 列{mc['col']+1}: {mc}")
    
    return merged_cells


def main():
    if len(sys.argv) < 2:
        print("用法: python docx_table_inspector.py <file.docx>")
        sys.exit(1)
    
    filepath = sys.argv[1]
    print(f"正在分析: {filepath}")
    
    doc = Document(filepath)
    
    print(f"\n文档信息:")
    print(f"  段落数: {len(doc.paragraphs)}")
    print(f"  表格数: {len(doc.tables)}")
    print(f"  节数: {len(doc.sections)}")
    
    all_merged = []
    for idx, table in enumerate(doc.tables):
        merged = inspect_table(table, idx)
        all_merged.extend(merged)
    
    print(f"\n{'='*60}")
    print(f"总结: 共发现 {len(all_merged)} 个合并单元格")
    print(f"{'='*60}")


if __name__ == "__main__":
    main()
