---
name: docx-table-editing
description: 处理 docx 文件中表格的编辑、读取、合并单元格（colspan/rowspan）、格式保留。适用于施工方案生成、合同模板填充、批量文档生成等场景。
version: 1.0.0
author: 上河一号
metadata:
  hermes:
    tags: [docx, table, merged-cells, ooxml, document-generation]
    priority: normal
---

# DOCX 表格编辑技能

## 用途

处理 Word (.docx) 文件中的表格，特别是：
- 读取含合并单元格的表格结构
- 创建含合并单元格的新表格
- 模板填充（Mail Merge）
- 格式保留的文档生成

## 核心问题

| 问题 | 原因 | 解决方案 |
|------|------|----------|
| python-docx 无法读取 colspan/rowspan | 高层 API 不暴露 OOXML 的 `w:gridSpan` 和 `w:vMerge` | 直接解析 XML |
| 合并单元格显示为空 | 合并单元格在内存中是同一对象 | 检查 `_tc` 元素是否相同 |
| 无法创建合并单元格 | python-docx 没有 `merge_cells()` 方法 | 用 `cell.merge(other_cell)` 或操作 XML |

## 技术选型

| 场景 | 推荐方案 | 库 |
|------|----------|-----|
| 简单表格（无合并） | python-docx | `pip install python-docx` |
| 复杂表格（合并单元格） | Aspose.Words | `pip install aspose-words` |
| 模板填充 | docx-mailmerge | `pip install python-docx-mailmerge` |
| Jinja2 模板 | docxtpl | `pip install docxtpl` |
| 格式提取+复现 | docx-format-replicator | 见 references/docx-format-replicator.md |

## 诊断工具

```bash
# 诊断表格结构（合并单元格位置、colspan/rowspan）
python scripts/docx_table_inspector.py <file.docx>
```

## 读取合并单元格（python-docx + XML）

```python
from docx import Document
from lxml import etree

ns = {'w': 'http://schemas.openxmlformats.org/wordprocessingml/2006/main'}

doc = Document("template.docx")
table = doc.tables[0]

for row_idx, row in enumerate(table.rows):
    for cell in row.cells:
        tcPr = cell._tc.find('w:tcPr', ns)
        if tcPr is not None:
            grid_span = tcPr.find('w:gridSpan', ns)
            v_merge = tcPr.find('w:vMerge', ns)
            colspan = int(grid_span.get('{http://...}val', 1)) if grid_span is not None else 1
            rowspan = v_merge is not None
```

## 创建合并单元格（python-docx）

```python
from docx import Document

doc = Document()
table = doc.add_table(rows=3, cols=4)

# 水平合并（colspan）
table.cell(0, 0).merge(table.cell(0, 2))  # 合并前3个单元格

# 垂直合并（rowspan）
table.cell(0, 0).merge(table.cell(2, 0))  # 合并前3行
```

## 模板填充（Mail Merge）

```python
from mailmerge import MailMerge

document = MailMerge("template.docx")
document.merge(name="张三", company="ABC公司", amount="10000")
document.write("output.docx")
```

## 格式提取与复现

```python
# 提取格式模板
python scripts/extract_format.py template.docx format_template.json

# 生成新文档
python scripts/generate_document.py format_template.json content.json output.docx
```

## Pitfalls（血泪教训）

1. **python-docx 的合并单元格检测**：`row.cells[0] == row.cells[1]` 为 True 表示合并，但无法区分 colspan/rowspan。必须解析 XML。
2. **Aspose.Words 的 CellMerge 属性**：`cell.cell_format.horizontal_merge` 可能返回 `NONE` 即使单元格已合并。需检查 XML 或文本内容。
3. **docxtpl 的表格行循环**：Jinja2 标签不能跨表格行。必须用特殊语法 `{% for item in items %}` 在表格行内。
4. **格式丢失**：python-docx 创建的新表格默认无样式。必须设置 `table.style = 'Table Grid'`。
5. **备份优先**：修改现有 docx 前必须备份。write_file 是全量覆盖，内容丢失无法撤销。

## 推荐 Skills 安装

| Skill | 来源 | 用途 |
|-------|------|------|
| anthropics/skills/docx | Anthropic 官方 | 基础 docx 操作 |
| claude-office-skills/docx-manipulation | community | python-docx 封装 |
| docx-format-replicator | community | 格式提取+复现 |

## 写作风格要求

- **通俗易懂**：口语化中文、先给结论再给细节、多用表格和场景对照
- **代码示例配注释**：每个代码块都要有注释说明
- **功能点标注**：每个功能点标注 ⚠️ 注意事项或 💡 技巧
- **章节标题用问句**：如"如何读取合并单元格？"
- **不主动执行**：先问清楚目标、格式、受众、成功标准

## 参考文档

- [python-docx 表格 API](https://python-docx.readthedocs.io/en/latest/user/tables.html)
- [python-docx 合并单元格](https://python-docx.readthedocs.io/en/latest/dev/analysis/features/table/cell-merge.html)
- [Aspose.Words 文档](https://docs.aspose.com/words/python/)
- [docxtpl 文档](https://docxtpl.readthedocs.io/)